<?php

define('BASE_URL', 'http://localhost/php-mvc/public');