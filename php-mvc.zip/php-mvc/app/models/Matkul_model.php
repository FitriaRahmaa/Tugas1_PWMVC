<?php

class Matkul_model 
{
    private $table = 'matkul';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    // function untuk menampilkan seluruh data mata kuliah
    public function getAllMatkul()
    {
        $this->db->query("SELECT * FROM ".$this->table);
        return $this->db->resultSet();
    }

    // function tambah data mahasiswa
    public function tambahDataMatkul($data)
    {
        $query = "INSERT INTO matkul values 
        (null, :kode_matkul, :nama_matkul, :kelas, :sks, :semester)";

        $this->db->query($query);
        // memasukan nama filed
        $this->db->bind('kode_matkul', $data['kode_matkul']);
        $this->db->bind('nama_matkul', $data['nama_matkul']);
        $this->db->bind('kelas', $data['kelas']);
        $this->db->bind('sks', $data['sks']);
        $this->db->bind('semester', $data['semester']);
        
        // eksekusi insert
        $this->db->execute();

        return $this->db->rowCount();
    }

    // function mengambil kode matkul
    public function getMatkulById($id_matkul)
    {
        $this->db->query("SELECT * FROM ".$this->table." WHERE id_matkul = :id_matkul");
        $this->db->bind('id_matkul', $id_matkul);
        return $this->db->single();
    }

    // update data matakuliah
    public function updateDataMatkul($data)
    {
        $query = "UPDATE matkul SET kode_matkul = :kode_matkul, nama_matkul = :nama_matkul, kelas = :kelas, sks = :sks, semester = :semester  WHERE id_matkul = :id_matkul";
        
        $this->db->query($query);
        // memasukan nama filed
        $this->db->bind('kode_matkul', $data['kode_matkul']);
        $this->db->bind('nama_matkul', $data['nama_matkul']);
        $this->db->bind('kelas', $data['kelas']);
        $this->db->bind('sks', $data['sks']);
        $this->db->bind('semester', $data['semester']); 
        $this->db->bind('id_matkul', $data['id_matkul']);

        $this->db->execute();

        return $this->db->rowCount();  
    }

    public function hapusDataMatkul($id_matkul)
    {
        $query = "DELETE FROM matkul WHERE id_matkul = :id_matkul";
        $this->db->query($query);
        $this->db->bind('id_matkul', $id_matkul);
        
        $this->db->execute();

        return $this->db->rowCount();
    }

}