<?php

class User_model
{
    private $nama = 'Fitria Rahma Agustina';

    public function getUser()
    {
        return $this->nama;
    }
}
