<?php

class Matkul extends Controller
{
    public function index()
    {
        $data['judul'] = "Daftar Mata Kuliah";
        // ambil data matakuliah dari model
        $data['matkul'] = $this->model('Matkul_model')->getAllMatkul();
        $this->view('templates/header', $data);
        $this->view('matkul/index', $data);        
        $this->view('templates/footer');
    }

    // kirim flash / notifikasi tambah dari model tambah
    public function tambah()
    {
        if($this->model('Matkul_model')->tambahDataMatkul($_POST) > 0){
            Flasher::setFlash('berhasil','ditambahkan','success');
            header('Location:'.BASE_URL.'/matkul');
            exit;
        } else {
            Flasher::setFlash('gagal','ditambahkan','danger');
            header('Location:'.BASE_URL.'/matkul');
            exit;
        }
    }
    
    // function untuk mengubah ke json untuk mengupdate 
    // menggunakan jquery
    public function getedit()
    {
        echo json_encode($this->model('Matkul_model')->getMatakulById($_POST['id_matkul']));
    }

    // kirim flash / notifikasi edit dari model matakuliah
    public function edit()
    {
        if($this->model('Matkul_model')->updateDataMatkul($_POST) > 0){
            Flasher::setFlash('berhasil','diupdate','success');
            header('Location:'.BASE_URL.'/matkul');
            exit;
        } else {
            Flasher::setFlash('gagal','diupdate','danger');
            header('Location:'.BASE_URL.'/matkul');
            exit;
        }
    }

    // function untuk hapus
    public function hapus($id_matkul)
    {
        if( $this->model('Matkul_model')->hapusDataMatkul($id_matkul) > 0 ) {
            Flasher::setFlash('berhasil', 'dihapus', 'success');
            header('Location: ' . BASE_URL . '/matkul');
            exit;
        } else {
            Flasher::setFlash('gagal', 'dihapus', 'danger');
            header('Location: ' . BASE_URL . '/matkul');
            exit;
        }
    }



}